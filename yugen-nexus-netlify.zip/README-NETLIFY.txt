YUGEN NEXUS — NETLIFY DEPLOYMENT

1) Upload this folder/repository to GitHub and connect it to Netlify.
2) Create a PostgreSQL database on Neon. Run database-schema.sql in the Neon SQL editor.
3) In Netlify > Site configuration > Environment variables, set:
   DATABASE_URL              = Neon connection string (include SSL options supplied by Neon)
   JWT_SECRET                = random secret, at least 32 random bytes
   TELEGRAM_ACCOUNT_BOT_TOKEN = NEW token for registration/admin events
   TELEGRAM_REPORT_BOT_TOKEN  = NEW token for bug reports and “Laporan Diterima”
   TELEGRAM_CHAT_ID          = private admin chat ID, e.g. 7890493162
   OWNER_EMAIL               = email address reserved for username zill
   OWNER_BOOTSTRAP_PASSWORD  = one-time initial owner registration password (keep secret)
   TELEGRAM_WEBHOOK_SECRET   = random secret string used for Telegram webhook verification
4) Deploy the site. Node 20+ is required.
5) Open your bot once and press Start. Set its webhook to:
   https://api.telegram.org/bot<NEW_REPORT_BOT_TOKEN>/setWebhook?url=https://YOUR-SITE.netlify.app/api/telegram-webhook&secret_token=<TELEGRAM_WEBHOOK_SECRET>
   Telegram will call the Netlify Function when the admin presses “Laporan Diterima”.
6) Register the owner account using username zill, exactly the OWNER_EMAIL value, and the OWNER_BOOTSTRAP_PASSWORD value. Other users cannot claim this username/email. Keep OWNER_BOOTSTRAP_PASSWORD secret; after owner registration you may rotate it to a new random value.
7) The owner can then assign developer roles from Admin Panel. When maintenance is enabled, only the owner account (role owner) can pass the Netlify Edge maintenance gate; developers and normal users are blocked.

SECURITY NOTES
- Revoke both Telegram bot tokens previously pasted into chat using BotFather. They are considered exposed.
- Never put bot tokens, database credentials, JWT secrets, or OWNER_EMAIL admin configuration in index.html.
- Passwords are bcrypt-hashed and are never sent to Telegram. Telegram receives username, email, role, and event metadata only.
- Password length: minimum 8 characters; maximum 72 UTF-8 bytes (bcrypt input limit).
- Reports accept PNG/JPEG/WEBP up to 3.5 MB. The screenshot is forwarded to the configured Telegram admin chat.
- The “Laporan Diterima” callback updates report status in PostgreSQL. The browser-side confirmation polling is included in index.html.
- This package does not implement the pre-existing third-party deployment provider integration; that endpoint returns HTTP 501 rather than pretending it worked.
